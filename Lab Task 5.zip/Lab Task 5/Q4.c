#include<stdio.h>
int main()
{
	char Alp;
	printf("Enter Alphabet: ");
	scanf("%c",&Alp);
	if(Alp>='A'&&Alp<='Z')
	{
		printf("Entered Alphabet '%c' is Capital.",Alp);
	}
	else if(Alp>='a'&&Alp<='z')
	{
		printf("Entered Alphabet '%c' is Small.",Alp);
	}
	else
	{
		printf("Invalid Character");
	}
	
	return 0;
}