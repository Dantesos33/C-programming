#include<stdio.h>
int main()
{
	int num1,num2;
	printf("Enter First Number: ");
	scanf("%d",&num1);
	printf("Enter Second Number: ");
	scanf("%d",&num2);
	if(num1%2==0&&num2%2==0)
	{
		printf("You Have Entered Two Even Numbers");
	}
	else if(num1%2==0&&num2%2!=0)
	{
		printf("\nYou Have Entered One Even Number And One Odd Number\nFirst Number is Even And Second is Odd");
	}
	else if(num1%2!=0&&num2%2==0)
	{
		printf("\nYou Have Entered One Even Number And One Odd Number\nFirst Number is Odd And Second is Even");
	}
	else if(num1%2!=0&&num2%2!=0)
	{
		printf("You Have Entered Two Odd Numbers");
	}
	else
	{
		printf("Neither Even nor Odd");
	}
	return 0;
}