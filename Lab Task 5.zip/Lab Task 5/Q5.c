#include<stdio.h>
int main()
{
	float a,b;
	char op;
	printf("     >>>> CALCULATOR <<<<\n\n");
	printf("Press '*' For Multiplication\n");
	printf("Press '/' For Division\n");
	printf("Press '+' For Addition\n");
	printf("Press '-' For Subtraction\n");
	printf("Enter Operation: ");
	scanf("%c",&op);
	printf("Enter two numbers\n");
	scanf("%f %f",&a,&b);
	printf("First Number is '%.0f'\nSecond Number is '%.0f'\nOperation you have chosen is '%c'\n",a,b,op);
	switch(op)
	{
		case '*':
			printf("%.0f * %.0f = %.2f",a,b,a*b);
			break;
		case '/':
			printf("%.0f / %.0f = %.2f",a,b,a/b);
			break;
		case '+':
			printf("%.0f + %.0f = %.2f",a,b,a+b);
				break;
		case '-':
			printf("%.0f - %.0f = %.2f",a,b,a-b);
				break;
				default:
					printf("Invalid Operator!!");
					break;
	}
}