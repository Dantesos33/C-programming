#include <stdio.h>
int main()
{
	printf("\n  **** Welcome to Contact Management System ****\n\n");
	printf("\n\t\tMAIN MENU:\n");
	printf("\t=========================\n");
	printf("\t[1] Add a new Contact\n");
	printf("\t[2] List all COntacts\n");
	printf("\t[3] Search for Contact\n");
	printf("\t[4] Edit a Contact\n");
	printf("\t[5] Delete a Contact\n");
	printf("\t[0] Exit\n");
	printf("\t===================\n");
	printf("\tEnter the Choice:");
	return 0;
}
