#include <stdio.h>
int main()
{
	printf("\n\t***********************************\n");
	printf("\t*PASSWORD PROTECTED PERSONAL DIARY*\n");
	printf("\t***********************************\n");
	printf("\t\tMAIN MENU \n\n");
	printf("\tADD RECORD    [1]\n");
	printf("\tVIEW RECORD   [2]\n");
	printf("\tEDIT RECORD   [3]\n");
	printf("\tDELETE RECORD [4]\n");
	printf("\tEDIT PASSWORD [5]\n");
	printf("\tEXIT          [6]\n");
	return 0;
}
