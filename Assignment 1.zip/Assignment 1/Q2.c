#include<stdio.h>
int main()
{
    int n,r,sum=0;
    printf("Enter Four digit number: ");
    scanf("%d",&n);
    if (n>=1000 && n<=9999)
    {
        while (n>0)
        {
            r = n% 10;
            sum = sum + r;
            n = n/10;
        }
        printf("Sum of digits = %d \n",sum);
        if(sum%2==0)
        {
            printf("Cube of sum = %d\n", sum*sum*sum);
        }
        else
        {
            printf("Square of sum = %d\n",sum*sum);
        }
    }
    else
    {
        printf("Error!");
    }
}