#include<stdio.h>
int main()
{
	int t1,t2,sum,i,n;
	printf("Enter No. of Terms: ");
	scanf("%d",&n);
	t1=0;
	t2=1;
	printf("%d",t1);
	for(i=0;i<n;i++)
	{
	sum=t1+t2;
	t2=t1;
	t1=sum;
	printf(",%d",sum);
}
}
