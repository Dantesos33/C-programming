#include<stdio.h>
int main()
{
	int n,g;
 char c;
 e:
	printf("\n    >>>>Conversion<<<<\n");
	printf("B- Convert decimal to binary\n");
	printf("H- Convert decimal to hexadecimal\n");
	printf("O- Convert decimal to octal\n");
	printf("E- Exit\n");
	printf("Enter your choice: ");
	scanf("%c",&c);
					if(c=='E'||g=='E')
					{
							printf("Exit\n");
							goto d;
					}
			
					else if(c=='H'||g=='H')
					{
					int n;
					printf("Enter Number in Decimal: ");
					scanf("%d",&n);
					printf("Number in Hexadecimal is %x\n",n);
					goto b;
					}
					
					else if(c=='O'||g=='O')
					{
						int n;
						printf("Enter Number in Decimal: ");
						scanf("%d",&n);
						printf("Number in Octal is %o\n",n);
						goto b;
					}
					
					else if(c=='B'||g=='B')
				{
		     		int a[10],n,i;
					printf("Enter number in Decimal: ");    
					scanf("%d",&n);    
					for(i=0;n>0;i++)    
					{    
					a[i]=n%2;    
					n=n/2;    
					}    
					printf("Number in Binary is :");    
					for(i=i-1;i>=0;i--)    
					{    
					printf("%d",a[i]);    
					}
      printf("\n");  
						goto b;	
				}
				if(c!='O'||c!='E'||c!='H'||c!='B')
				{
					printf("Invalid Option\n");
					goto d;
				}
				b:
				scanf("%c",&g);
				goto e;
				d:
		return 0;
}