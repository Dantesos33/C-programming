#include<stdio.h>
int main()
{
    int n,r,rev=0;
    printf("Enter 2 digit number: ");
    scanf("%d",&n);
    if(n>=10&&n<=99)
    {
        while(n>0)
        {
            r=n%10;
            rev=(rev*10)+r;
            n=n/10;
        }
        printf("Reversed number = %d",rev);
    }
    else
    {
        printf("Error!");
    }
}