#include<stdio.h>
int main ()
{
    int a,b;
    printf("Enter two numbers\n");
    scanf("%d %d",&a, &b);
    printf("First Number Before Swapping = %d\n",a);
    printf("Second Number Before Swapping = %d\n",b);
    a=a+b;
    b=a-b;
    a=a-b;
    printf("First Number After Swapping = %d\n",a);
    printf("Second Number After Swapping = %d\n",b);


}
