#include <stdio.h>
int main ()
{
    int i,j,n;
    printf("Enter Positive Integer: ");
    scanf("%d",&n);
    if(n>0)
    {
    for(i=1; i<=n; i++)
    {
        for(j=i; j<n; j++)
        {
            printf(" ");
        }
        for(j=1; j<=(2*i-1); j++)
        {
            if(i==n || j==1 ||j==(2*i-1))
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
    }
    else if(n==0)
    {
    printf("You Entered Zero!!");
    }
    else
    {
    printf("You Entered Negative Integer!!");
    }
}