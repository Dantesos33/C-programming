#include<stdio.h>
int main()
{
    char option;
    printf("********Menu********\n");
    printf("1- Armstrong number\n");
    printf("2- Digit sum\n");
    printf("3- Swap number\n");
    printf("4- Reverse number\n");
    printf("Enter your choice: ");
    scanf("%c",&option);
    switch(option)
    {
    case '1':
        armstrong();
        break;
    case '2':
        digit_sum();
        break;
    case '3':
        swap();
        break;
    case '4':
        reverse();
        break;
    default:
        printf("Invalid choice");
        break;
    }
}
int armstrong()
{
    int n,r,f,rem=0,j;
    printf("\n****Armstrong Number****\n");
    printf("Enter 3 digit number: ");
    scanf("%d",&n);
    f=n;
    j=n;
    
    if(f>=100&&f<=999||j>=100&&j<=999)
    {
        while(f>0)
        {
            f=f%10;
            printf("%d\n",j/100);
            j=j%100;
            printf("%d\n",j/10);
            j=j%10;
            printf("%d\n",j/1);
            f=f/10;
            j=j/10;
        }
    }
    rem=0;
    f=n;
    if(f>=100&&f<=999||j>=100&&j<=999)
    {
        while(f>0)
        {
            r=f%10;
            rem=(r*r*r)+rem;
            f=f/10;
        }
        printf("Sum = %d\n",rem);
    }
    else if(f<100||f>999||j<100||j>999)
    {
        printf("Error!");
        goto c;
    }
    if(rem==n)
    {
        printf("Number is Armstrong\n");
    }
    
    else if(rem!=n)
    {
        printf("Number is not Armstrong\n");
    }
    c:
    return 0;
}

int digit_sum()
{
    int n,r,sum=0;
    printf("\n********Digit Sum********\n");
    printf("Enter Four digit number: ");
    scanf("%d",&n);
    if (n>=1000 && n<=9999)
    {
        while (n>0)
        {
            r=n% 10;
            sum=sum + r;
            n=n/10;
        }
        printf("sum of digits = %d \n",sum);
    }
    else
    {
        printf("Error!");
    }
}
int swap()
{
    int a,b;
    printf("\n****Swap Numbers****\n");
    printf("Enter two numbers\n");
    scanf("%d %d",&a, &b);
    printf("First Number Before Swapping = %d\n",a);
    printf("Second Number Before Swapping = %d\n",b);
    a=a+b;
    b=a-b;
    a=a-b;
    printf("First Number After Swapping = %d\n",a);
    printf("Second Number After Swapping = %d\n",b);

}
int reverse()
{
    int n,r,rev=0;
    printf("\n****Reverse Numbers****\n");
    printf("Enter 2 digit number: ");
    scanf("%d",&n);
    if(n>=10&&n<=99)
    {
        while(n>0)
        {
            r=n%10;
            rev=(rev*10)+r;
            n=n/10;
        }
        printf("Reversed number = %d",rev);
    }
    else
    {
        printf("Error!");
    }
}
