#include<stdio.h>
#include<math.h>
int main()
{
    int n,r,f,rem=0,j;
    printf("Enter 3 digit number: ");
    scanf("%d",&n);
    f=n;
    j=n;
    
    if(f>=100&&f<=999||j>=100&&j<=999)
    {
        while(f>0)
        {
            f=f%10;
            printf("%d\n",j/100);
            j=j%100;
            printf("%d\n",j/10);
            j=j%10;
            printf("%d\n",j/1);
            f=f/10;
            j=j/10;
        }
    }
    rem=0;
    f=n;
    if(f>=100&&f<=999||j>=100&&j<=999)
    {
        while(f>0)
        {
            r=f%10;
            rem=(r*r*r)+rem;
            f=f/10;
        }
        printf("Sum = %d\n",rem);
    }
    else if(f<100||f>999||j<100||j>999)
    {
        printf("Error!");
        goto c;
    }
    if(rem==n)
    {
        printf("Number is Armstrong\n");
    }
    
    else if(rem!=n)
    {
        printf("Number is not Armstrong\n");
    }
    c:
    return 0;
}