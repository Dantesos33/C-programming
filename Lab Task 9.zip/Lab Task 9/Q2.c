/*Using pow(), write a C program to compute the surface area and volume of a
cube.*/
#include <stdio.h>
#include <math.h>

int main() 
{
    float side_length;
    float surface_area;
    float volume;

    printf("Enter the side length of the cube: ");
    scanf("%f", &side_length);

    surface_area = 6*pow(side_length, 2);
    volume = pow(side_length, 3);

    printf("Surface area: %.2f\n", surface_area);
    printf("Volume: %.2f\n", volume);

    return 0;
}

