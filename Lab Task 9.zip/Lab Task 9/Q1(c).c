/*copy one string into another string.*/
#include <stdio.h>
#include <string.h>

int main()
{
    char str1[100] = "String one Copied to String two";
    char str2[100];
    int i;

    for (i = 0; str1[i] != '\0'; i++) 
    {
        str2[i] = str1[i];
    }
    str2[i] = '\0';

    printf("str2: %s\n", str2);

    return 0;
}

