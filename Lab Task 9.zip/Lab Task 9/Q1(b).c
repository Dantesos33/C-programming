/*concatenate two strings i.e. str1 and str2 are the two strings and after concatenation str1 will have str2
joined/concatenated after it.*/
#include <stdio.h>
#include <string.h>

int main() 
{
    char str1[100] = "This is a ";
    char str2[] = "String.";
    int i, j;

    for (i = 0; str1[i] != '\0'; i++); 
    for (j = 0; str2[j] != '\0'; j++)  
	{
        str1[i+j] = str2[j];
    }
    str1[i+j] = '\0'; 

    printf("%s\n", str1);

    return 0;
}

