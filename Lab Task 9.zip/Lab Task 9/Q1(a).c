/*find whether two strings, str1 and
str2 are exactly equal or not.*/
#include<stdio.h>
int main()
{
    char str1[50], str2[50];
    int i=0, flag=0;
    printf("Enter the First String: ");
    gets(str1);
    printf("Enter the Second String: ");
    gets(str2);
    while(str1[i]!='\0' || str2[i]!='\0')
    {
        if(str1[i]!=str2[i])
        {
            flag = 1;
            break;
        }
        i++;
    }
    if(flag==0)
        printf("\nStrings are Equal");
    else
        printf("\nStrings are not Equal");
    printf("\n");
    return 0;
}
