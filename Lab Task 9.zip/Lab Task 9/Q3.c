/*Write a C Program to find roots of a quadratic equation when coefficients are
entered by the user.*/
#include <stdio.h>
#include <math.h>

int main()
{
    float a, b, c;
    float root1, root2;
    float d;

    printf("Enter the coefficients a, b, and c:\n");
    scanf("%f%f%f", &a, &b, &c);
    d = b*b - 4*a*c;
    if (d > 0)
    {
        root1 = (-b + sqrt(d)) / (2*a);
        root2 = (-b - sqrt(d)) / (2*a);
        printf("Root 1: %.2f\n", root1);
        printf("Root 2: %.2f\n", root2);
    }
    else if (d == 0)
    {
        root1 = -b / (2*a);
        printf("Root: %.2f\n", root1);
    }
    else
    {
        printf("No real roots.\n");
    }

    return 0;
}

