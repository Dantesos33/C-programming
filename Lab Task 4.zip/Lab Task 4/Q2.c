#include<stdio.h>
int main ()
{ 
float a, b, c,sum; 
	printf("Enter the first number: ");
	scanf("%f",&a);
	printf("Enter the second number: ");
	scanf("%f",&b);
	printf("Enter the third number: ");
	scanf("%f",&c);
	sum=a+b+c;
	printf("Sum = %f",sum);
	  
	
	
}
