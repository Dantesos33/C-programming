/*Write a C program to count the number of vowels in a given input file.*/
#include <stdio.h>
#include <ctype.h>

int main()
{
    //input.txt named file must be present
    FILE *fp = fopen("input.txt", "r");
    if (fp == NULL)
    {
        printf("Error opening file\n");
        return 1;
    }
    int vowel_count = 0;

    char ch = fgetc(fp);
    while (ch != EOF)
    {
        if (ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch == 'o' || ch == 'O' || ch == 'u' || ch == 'U')
        {
            vowel_count++;
        }
        ch = fgetc(fp);
    }
    fclose(fp);
    printf("Number of vowels: %d\n", vowel_count);

    return 0;
}

