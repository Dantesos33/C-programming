/*Write a C program to read a four digit integer from an input file and write the
sum of those four digits in another file*/
#include <stdio.h>

int main()
{
    //input.txt named file must be present
    FILE *input_file = fopen("input.txt", "r");

    int number;
    fscanf(input_file, "%d", &number);

    fclose(input_file);

    int sum = 0;
    while (number > 0) 
    {
        sum += number % 10;
        number /= 10;
    }

    FILE *output_file = fopen("output.txt", "w");

    fprintf(output_file, "%d", sum);

    fclose(output_file);

    return 0;
}

