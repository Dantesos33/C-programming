/*Write a C program to replace all numbers in a file to $.*/
#include <stdio.h>
#include <ctype.h>

int main()
{
    //input.txt named file must be present
    FILE *input_file = fopen("input.txt", "r");


    FILE *output_file = fopen("output.txt", "w");

    int c;
    while ((c = fgetc(input_file)) != EOF)
    {

        if (isdigit(c))
        {
            fputc('$', output_file);
        }
        else
        {

            fputc(c, output_file);
        }
    }

    fclose(input_file);
    fclose(output_file);

    return 0;
}

