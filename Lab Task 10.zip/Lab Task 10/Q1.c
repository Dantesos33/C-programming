/* Write a C program to check whether a given 2D array is column-magic or not?
(every column has the same column sum).*/
#include <stdio.h>

int main()
{
    int i, j;
    int array[3][3];
    int sum;
    int column_sum;
    int is_column_magic = 1;

    printf("Enter the elements of the array: \n");
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            scanf("%d", &array[i][j]);

        }
    }

    sum = 0;
    for (i = 0; i < 3; i++)
    {
        sum += array[i][0];
    }

    for (j = 1; j < 3; j++)
    {
        column_sum = 0;
        for (i = 0; i < 3; i++)
        {
            column_sum += array[i][j];
        }
        if (column_sum != sum)
        {
            is_column_magic = 0;
            break;
        }
    }

    if (is_column_magic)
    {
        printf("The array is column-magic.\n");
    }
    else
    {
        printf("The array is not column-magic.\n");
    }

    return 0;
}

