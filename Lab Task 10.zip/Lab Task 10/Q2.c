/*Write a program that takes input in two dimensional arrays as matrix and
perform its addition and multiplication.*/
#include<stdio.h>

int main()
{
    int i, j, k;
    int matrix1[3][3];
    int matrix2[3][3];
    int sum[3][3];
    int product[3][3];

    printf("Enter the elements of matrix 1: \n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &matrix1[i][j]);
        }
    }

    printf("Enter the elements of matrix 2: \n");
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            scanf("%d", &matrix2[i][j]);
        }
    }
    //For Addition
    if (3 != 3 || 3 != 3) {
        printf("Error: The matrices are not compatible for addition.\n");
    }
    else
    {
        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++) {
                sum[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }

        printf("Sum: \n");
        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++) {
                printf("%d\t", sum[i][j]);
            }
            printf("\n");
        }
    }

    //For Multiplication
    if (3 != 3)
    {
        printf("Error: The matrices are not compatible for multiplication.\n");
    }
    else
    {
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 3; j++)
            {
                product[i][j] = 0;
                for(k = 0; k < 3; k++)
                {
                    product[i][j] += matrix1[i][k] * matrix2[k][j];
                }
            }
        }

        printf("Product: \n");
        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++) {
                printf("%d\t", product[i][j]);
            }
            printf("\n");
        }
    }

    return 0;
}

